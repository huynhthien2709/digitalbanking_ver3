package vn.funix.fx17332.java.asm03;

public interface Withdraw {
    boolean withdraw(double amount);
    boolean isAccept(double amount);

}
