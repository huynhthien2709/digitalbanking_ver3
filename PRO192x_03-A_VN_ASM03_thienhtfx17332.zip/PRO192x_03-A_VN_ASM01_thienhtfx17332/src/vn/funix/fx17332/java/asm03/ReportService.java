package vn.funix.fx17332.java.asm03;

public interface ReportService {
    void log(double amount);
}
